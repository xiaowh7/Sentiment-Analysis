__author__ = 'seven'
import re

infile = open('fullDataUsedForPaper.txt', 'r')
outfile = open('test.csv', 'w')
outfile1 = open('tweets.csv', 'w')
isFirst = True
for line in infile.readlines():
    if isFirst:
        isFirst = False
        continue
    sentiment = 'neural'
    line = line.strip('\n').split('\t')
    if line[0] == '1':
        sentiment = 'positive'
    elif line[0] == '0':
        sentiment = 'neutral'
    elif line[0] == '-1':
        sentiment = 'negative'
    tweetID = line[1]
    userID = line[2]
    tweet = line[6]
    chk = re.match(r'([a-zA-z0-9 \+\?\.\*\^\$\(\)\[\]\{\}\|\\/:;\'\"><,.#@!~`%&-_=])+$', tweet)
    if not chk:
        tweet = ''
    if not tweet == '':
        outfile.write('%s\t%s\t%s\t%s\n' % (tweetID, userID, sentiment, tweet))
        outfile1.write('%s\n' % tweet)

infile.close()
outfile.close()
outfile1.close()